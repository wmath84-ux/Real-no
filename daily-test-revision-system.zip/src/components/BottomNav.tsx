"use client";

import { usePathname } from "next/navigation";
import { useExitGuard } from "./ExitGuardContext";
import { BankIcon, ChartIcon, HomeIcon, TargetIcon, UserIcon } from "./icons";

const TABS = [
  { href: "/", label: "Home", icon: HomeIcon, match: (p: string) => p === "/" },
  { href: "/revision", label: "Bank", icon: BankIcon, match: (p: string) => p.startsWith("/revision") },
  { href: "/weak-topics", label: "Weak Spots", icon: TargetIcon, match: (p: string) => p.startsWith("/weak-topics") },
  { href: "/progress", label: "Progress", icon: ChartIcon, match: (p: string) => p.startsWith("/progress") },
  { href: "/profile", label: "Profile", icon: UserIcon, match: (p: string) => p.startsWith("/profile") },
];

export default function BottomNav() {
  const pathname = usePathname();
  const { navigate } = useExitGuard();

  return (
    <nav
      className="sticky bottom-0 z-30 border-t border-slate-200 bg-white/95 backdrop-blur pb-[env(safe-area-inset-bottom)]"
      aria-label="Bottom navigation"
    >
      <div className="grid grid-cols-5">
        {TABS.map((tab) => {
          const active = tab.match(pathname ?? "");
          const Icon = tab.icon;
          return (
            <button
              key={tab.href}
              type="button"
              onClick={() => navigate(tab.href)}
              aria-current={active ? "page" : undefined}
              className="flex min-h-[56px] flex-col items-center justify-center gap-0.5 py-2 text-[11px] font-medium transition-colors active:bg-slate-50"
            >
              <Icon className={`h-[22px] w-[22px] ${active ? "text-indigo-600" : "text-slate-400"}`} />
              <span className={active ? "text-indigo-600" : "text-slate-500"}>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
