import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  date,
  pgEnum,
  uniqueIndex,
} from "drizzle-orm/pg-core";

// ---------- Enums ----------
export const difficultyEnum = pgEnum("difficulty", ["easy", "medium", "hard"]);
export const testStatusEnum = pgEnum("test_status", [
  "not_started",
  "in_progress",
  "completed",
  "expired",
]);
export const revisionStatusEnum = pgEnum("revision_status", [
  "learning",
  "improving",
  "mastered",
]);
export const sessionStatusEnum = pgEnum("session_status", [
  "in_progress",
  "completed",
]);

// ---------- Core entities ----------
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull().default("📘"),
  color: text("color").notNull().default("indigo"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const topics = pgTable("topics", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id")
    .notNull()
    .references(() => subjects.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  topicId: integer("topic_id")
    .notNull()
    .references(() => topics.id, { onDelete: "cascade" }),
  subjectId: integer("subject_id")
    .notNull()
    .references(() => subjects.id, { onDelete: "cascade" }),
  difficulty: difficultyEnum("difficulty").notNull().default("medium"),
  prompt: text("prompt").notNull(),
  options: jsonb("options").$type<string[]>().notNull(),
  correctIndex: integer("correct_index").notNull(),
  explanation: text("explanation").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ---------- Daily test ----------
export const dailyTests = pgTable("daily_tests", {
  id: serial("id").primaryKey(),
  testDate: date("test_date", { mode: "string" }).notNull().unique(),
  title: text("title").notNull(),
  questionIds: jsonb("question_ids").$type<number[]>().notNull(),
  totalQuestions: integer("total_questions").notNull(),
  estimatedMinutes: integer("estimated_minutes").notNull().default(5),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const testAttempts = pgTable("test_attempts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  dailyTestId: integer("daily_test_id")
    .notNull()
    .references(() => dailyTests.id, { onDelete: "cascade" }),
  status: testStatusEnum("status").notNull().default("in_progress"),
  currentIndex: integer("current_index").notNull().default(0),
  score: integer("score").notNull().default(0),
  correctCount: integer("correct_count").notNull().default(0),
  wrongCount: integer("wrong_count").notNull().default(0),
  skippedCount: integer("skipped_count").notNull().default(0),
  timeSpentSeconds: integer("time_spent_seconds").notNull().default(0),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const testAnswers = pgTable(
  "test_answers",
  {
    id: serial("id").primaryKey(),
    attemptId: integer("attempt_id")
      .notNull()
      .references(() => testAttempts.id, { onDelete: "cascade" }),
    questionId: integer("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    selectedIndex: integer("selected_index"),
    isCorrect: boolean("is_correct"),
    isSkipped: boolean("is_skipped").notNull().default(true),
    answeredAt: timestamp("answered_at"),
  },
  (table) => ({
    attemptQuestionIdx: uniqueIndex("test_answers_attempt_question_idx").on(
      table.attemptId,
      table.questionId,
    ),
  }),
);

// ---------- Smart revision bank ----------
export const revisionItems = pgTable(
  "revision_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    questionId: integer("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    subjectId: integer("subject_id")
      .notNull()
      .references(() => subjects.id, { onDelete: "cascade" }),
    topicId: integer("topic_id")
      .notNull()
      .references(() => topics.id, { onDelete: "cascade" }),
    status: revisionStatusEnum("status").notNull().default("learning"),
    successStreak: integer("success_streak").notNull().default(0),
    timesSeen: integer("times_seen").notNull().default(0),
    timesCorrect: integer("times_correct").notNull().default(0),
    timesWrong: integer("times_wrong").notNull().default(0),
    lastResult: text("last_result"),
    sourceAttemptId: integer("source_attempt_id"),
    addedAt: timestamp("added_at").notNull().defaultNow(),
    lastRevisedAt: timestamp("last_revised_at"),
    masteredAt: timestamp("mastered_at"),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    userQuestionIdx: uniqueIndex("revision_items_user_question_idx").on(
      table.userId,
      table.questionId,
    ),
  }),
);

export const revisionSessions = pgTable("revision_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  status: sessionStatusEnum("status").notNull().default("in_progress"),
  filterSubjectId: integer("filter_subject_id"),
  filterTopicId: integer("filter_topic_id"),
  filterStatus: text("filter_status"),
  questionIds: jsonb("question_ids").$type<number[]>().notNull(),
  currentIndex: integer("current_index").notNull().default(0),
  totalQuestions: integer("total_questions").notNull(),
  correctCount: integer("correct_count").notNull().default(0),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const revisionSessionAnswers = pgTable(
  "revision_session_answers",
  {
    id: serial("id").primaryKey(),
    sessionId: integer("session_id")
      .notNull()
      .references(() => revisionSessions.id, { onDelete: "cascade" }),
    revisionItemId: integer("revision_item_id")
      .notNull()
      .references(() => revisionItems.id, { onDelete: "cascade" }),
    questionId: integer("question_id")
      .notNull()
      .references(() => questions.id, { onDelete: "cascade" }),
    selectedIndex: integer("selected_index"),
    isCorrect: boolean("is_correct"),
    isSkipped: boolean("is_skipped").notNull().default(true),
    statusBefore: revisionStatusEnum("status_before"),
    statusAfter: revisionStatusEnum("status_after"),
    answeredAt: timestamp("answered_at"),
  },
  (table) => ({
    sessionQuestionIdx: uniqueIndex(
      "revision_session_answers_session_question_idx",
    ).on(table.sessionId, table.questionId),
  }),
);
