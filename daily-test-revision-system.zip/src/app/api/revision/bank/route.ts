import { getRevisionBank, type BankFilters } from "@/server/revision-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const url = new URL(req.url);
    const filters: BankFilters = {
      subjectId: url.searchParams.get("subjectId") ? Number(url.searchParams.get("subjectId")) : undefined,
      topicId: url.searchParams.get("topicId") ? Number(url.searchParams.get("topicId")) : undefined,
      difficulty: (url.searchParams.get("difficulty") as BankFilters["difficulty"]) || undefined,
      status: (url.searchParams.get("status") as BankFilters["status"]) || undefined,
      search: url.searchParams.get("search") || undefined,
      sort: (url.searchParams.get("sort") as BankFilters["sort"]) || undefined,
    };
    const data = await getRevisionBank(DEMO_USER_ID, filters);
    return Response.json({ ok: true, data });
  } catch (err) {
    console.error(err);
    return Response.json({ ok: false, error: "Failed to load revision bank." }, { status: 500 });
  }
}
