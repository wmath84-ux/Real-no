import { getAllSubjects, getTopicsForSubject } from "@/server/revision-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function GET() {
  void DEMO_USER_ID;
  try {
    const [subjects, topics] = await Promise.all([getAllSubjects(), getTopicsForSubject()]);
    return Response.json({ ok: true, data: { subjects, topics } });
  } catch (err) {
    console.error(err);
    return Response.json({ ok: false, error: "Failed to load metadata." }, { status: 500 });
  }
}
