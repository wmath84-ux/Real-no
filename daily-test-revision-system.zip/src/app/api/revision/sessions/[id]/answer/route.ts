import {
  saveRevisionAnswer,
  updateRevisionSessionIndex,
  ServiceError,
} from "@/server/revision-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const sessionId = Number(id);
  if (!Number.isFinite(sessionId)) {
    return Response.json({ ok: false, error: "Invalid session id." }, { status: 400 });
  }
  try {
    const body = await req.json();
    const { questionId, selectedIndex, currentIndex } = body as {
      questionId: number;
      selectedIndex: number | null;
      currentIndex?: number;
    };
    if (typeof questionId !== "number") {
      return Response.json({ ok: false, error: "questionId is required." }, { status: 400 });
    }
    const result = await saveRevisionAnswer(sessionId, DEMO_USER_ID, questionId, selectedIndex ?? null);
    if (typeof currentIndex === "number") {
      await updateRevisionSessionIndex(sessionId, DEMO_USER_ID, currentIndex);
    }
    return Response.json({ ok: true, data: result });
  } catch (err) {
    if (err instanceof ServiceError) {
      return Response.json({ ok: false, error: err.message, code: err.code }, { status: 409 });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to save answer." }, { status: 500 });
  }
}
