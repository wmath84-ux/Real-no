import { submitRevisionSession, ServiceError } from "@/server/revision-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const sessionId = Number(id);
  if (!Number.isFinite(sessionId)) {
    return Response.json({ ok: false, error: "Invalid session id." }, { status: 400 });
  }
  try {
    const result = await submitRevisionSession(sessionId, DEMO_USER_ID);
    return Response.json({ ok: true, data: result });
  } catch (err) {
    if (err instanceof ServiceError) {
      return Response.json({ ok: false, error: err.message, code: err.code }, { status: 409 });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to submit revision session." }, { status: 500 });
  }
}
