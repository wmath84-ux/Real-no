import { startRevisionSession, findActiveSession, ServiceError } from "@/server/revision-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const active = await findActiveSession(DEMO_USER_ID);
    return Response.json({ ok: true, data: active });
  } catch (err) {
    console.error(err);
    return Response.json({ ok: false, error: "Failed to check active session." }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const { subjectId, topicId, status, limit } = body as {
      subjectId?: number;
      topicId?: number;
      status?: string;
      limit?: number;
    };
    const session = await startRevisionSession(DEMO_USER_ID, { subjectId, topicId, status, limit });
    return Response.json({ ok: true, data: { sessionId: session.id } });
  } catch (err) {
    if (err instanceof ServiceError) {
      const status = err.code === "NO_ITEMS" ? 422 : 409;
      return Response.json({ ok: false, error: err.message, code: err.code }, { status });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to start revision session." }, { status: 500 });
  }
}
