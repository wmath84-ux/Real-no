import { startOrResumeAttempt, ServiceError } from "@/server/test-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function POST() {
  try {
    const attempt = await startOrResumeAttempt(DEMO_USER_ID);
    return Response.json({ ok: true, data: { attemptId: attempt.id } });
  } catch (err) {
    if (err instanceof ServiceError) {
      return Response.json({ ok: false, error: err.message, code: err.code }, { status: 409 });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to start test." }, { status: 500 });
  }
}
