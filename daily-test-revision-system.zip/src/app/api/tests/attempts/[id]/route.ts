import { getAttemptForPlayer, ServiceError } from "@/server/test-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const attemptId = Number(id);
  if (!Number.isFinite(attemptId)) {
    return Response.json({ ok: false, error: "Invalid attempt id." }, { status: 400 });
  }
  try {
    const data = await getAttemptForPlayer(attemptId, DEMO_USER_ID);
    return Response.json({ ok: true, data });
  } catch (err) {
    if (err instanceof ServiceError) {
      const status = err.code === "NOT_FOUND" ? 404 : 409;
      return Response.json({ ok: false, error: err.message, code: err.code }, { status });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to load test." }, { status: 500 });
  }
}
