import { updateAttemptIndex, ServiceError } from "@/server/test-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const attemptId = Number(id);
  if (!Number.isFinite(attemptId)) {
    return Response.json({ ok: false, error: "Invalid attempt id." }, { status: 400 });
  }
  try {
    const body = await req.json();
    const { currentIndex } = body as { currentIndex: number };
    if (typeof currentIndex !== "number") {
      return Response.json({ ok: false, error: "currentIndex is required." }, { status: 400 });
    }
    const result = await updateAttemptIndex(attemptId, DEMO_USER_ID, currentIndex);
    return Response.json({ ok: true, data: result });
  } catch (err) {
    if (err instanceof ServiceError) {
      return Response.json({ ok: false, error: err.message, code: err.code }, { status: 409 });
    }
    console.error(err);
    return Response.json({ ok: false, error: "Failed to update position." }, { status: 500 });
  }
}
