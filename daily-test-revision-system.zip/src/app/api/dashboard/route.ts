import { getDashboardData } from "@/server/stats-service";
import { DEMO_USER_ID } from "@/server/db-utils";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const data = await getDashboardData(DEMO_USER_ID);
    return Response.json({ ok: true, data });
  } catch (err) {
    console.error(err);
    return Response.json({ ok: false, error: "Failed to load dashboard." }, { status: 500 });
  }
}
