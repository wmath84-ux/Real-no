import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import Providers from "@/components/Providers";

export const metadata: Metadata = {
  title: "Daily 5 — Test & Revision",
  description: "Daily 5-Minute Test with a Smart Revision Bank to master your weak topics.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#4f46e5",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-200 text-slate-900 antialiased">
        <Providers>
          <div className="mx-auto flex h-dvh max-w-[480px] flex-col overflow-hidden bg-slate-50 sm:shadow-2xl">
            {children}
          </div>
        </Providers>
      </body>
    </html>
  );
}
