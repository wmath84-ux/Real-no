"use client";

import { use } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import PageShell from "@/components/PageShell";
import { Card, ErrorState, FullScreenLoader, PrimaryButton, ProgressBar, SecondaryButton } from "@/components/ui";
import { ApiError, fetchTestResult } from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { CheckIcon, ClockIcon, SparklesIcon, XIcon } from "@/components/icons";

function formatDuration(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  if (m === 0) return `${s}s`;
  return `${m}m ${s}s`;
}

function scoreMessage(score: number) {
  if (score >= 90) return "Outstanding work! 🎉";
  if (score >= 70) return "Great job today! 👏";
  if (score >= 50) return "Good effort, keep going! 💪";
  return "Every test makes you sharper. Let's revise! 📘";
}

export default function TestResultPage({ params }: { params: Promise<{ attemptId: string }> }) {
  const { attemptId: attemptIdStr } = use(params);
  const attemptId = Number(attemptIdStr);
  const router = useRouter();

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: queryKeys.testResult(attemptId),
    queryFn: () => fetchTestResult(attemptId),
    enabled: Number.isFinite(attemptId),
  });

  return (
    <PageShell title="Test Result" backHref="/">
      {isLoading && <FullScreenLoader label="Calculating your results…" />}
      {isError && (
        <ErrorState
          message={error instanceof ApiError ? error.message : "Could not load your result."}
          onRetry={() => refetch()}
        />
      )}
      {data && (
        <div className="animate-fade-in space-y-4 px-4 py-4 pb-8">
          <Card className="bg-gradient-to-br from-indigo-600 to-violet-600 text-center text-white">
            <p className="text-xs font-semibold uppercase tracking-wide text-indigo-100">Your Score</p>
            <p className="mt-1 text-5xl font-extrabold">{data.score}%</p>
            <p className="mt-1 text-sm text-indigo-100">{scoreMessage(data.score)}</p>
            <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-indigo-100">
              <ClockIcon className="h-4 w-4" /> Completed in {formatDuration(data.timeSpentSeconds)}
            </div>
          </Card>

          <div className="grid grid-cols-3 gap-3">
            <ResultChip icon={<CheckIcon className="h-5 w-5 text-emerald-600" />} label="Correct" value={data.correctCount} tone="bg-emerald-50" />
            <ResultChip icon={<XIcon className="h-5 w-5 text-rose-600" />} label="Wrong" value={data.wrongCount} tone="bg-rose-50" />
            <ResultChip icon={<SparklesIcon className="h-5 w-5 text-slate-500" />} label="Skipped" value={data.skippedCount} tone="bg-slate-50" />
          </div>

          <Card>
            <div className="flex items-center justify-between">
              <h2 className="text-[15px] font-semibold text-slate-900">Accuracy</h2>
              <span className="text-sm font-bold text-indigo-600">{data.accuracy}%</span>
            </div>
            <ProgressBar value={data.accuracy} className="mt-2" />
            <p className="mt-2 text-xs text-slate-400">
              {data.correctCount} correct out of {data.totalQuestions} questions
            </p>
          </Card>

          <Card>
            <h2 className="mb-3 text-[15px] font-semibold text-slate-900">Topic Breakdown</h2>
            <div className="space-y-3">
              {data.topicBreakdown
                .sort((a, b) => a.accuracy - b.accuracy)
                .map((t) => (
                  <div key={t.topicId} className="flex items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-slate-50 text-lg">
                      {t.subjectIcon}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <p className="truncate text-sm font-medium text-slate-800">{t.topicName}</p>
                        <span className="ml-2 text-xs font-semibold text-slate-600">
                          {t.correct}/{t.total} · {t.accuracy}%
                        </span>
                      </div>
                      <ProgressBar value={t.accuracy} className="mt-1.5" />
                    </div>
                  </div>
                ))}
            </div>
          </Card>

          <div className="space-y-3 pt-1">
            <PrimaryButton onClick={() => router.push(`/test/review/${attemptId}`)}>Review Answers</PrimaryButton>
            <SecondaryButton onClick={() => router.push("/revision")}>Open Revision Bank</SecondaryButton>
            {(data.wrongCount > 0 || data.skippedCount > 0) && (
              <SecondaryButton onClick={() => router.push("/revision/session")}>
                Retake Revision Session
              </SecondaryButton>
            )}
          </div>
        </div>
      )}
    </PageShell>
  );
}

function ResultChip({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: string }) {
  return (
    <div className={`flex flex-col items-center gap-1 rounded-2xl py-3 ${tone}`}>
      {icon}
      <span className="text-lg font-bold text-slate-900">{value}</span>
      <span className="text-[10px] font-medium text-slate-500">{label}</span>
    </div>
  );
}
