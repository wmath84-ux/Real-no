"use client";

import { use, useEffect, useRef, useState, type TouchEvent as ReactTouchEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import PageShell from "@/components/PageShell";
import { useExitGuard } from "@/components/ExitGuardContext";
import { Badge, ErrorState, FullScreenLoader, PrimaryButton, ProgressBar, SecondaryButton } from "@/components/ui";
import {
  ApiError,
  fetchRevisionSessionPlayer,
  navigateRevisionSession,
  saveRevisionAnswer,
  submitRevisionSession,
} from "@/lib/api-client";
import { queryKeys } from "@/lib/query-keys";
import { CheckIcon, ChevronRightIcon } from "@/components/icons";

const OPTION_LETTERS = ["A", "B", "C", "D", "E", "F"];

export default function RevisionSessionPlayerPage({ params }: { params: Promise<{ sessionId: string }> }) {
  const { sessionId: sessionIdStr } = use(params);
  const sessionId = Number(sessionIdStr);
  const router = useRouter();
  const queryClient = useQueryClient();
  const { setGuard } = useExitGuard();

  const playerQuery = useQuery({
    queryKey: queryKeys.revisionSessionPlayer(sessionId),
    queryFn: () => fetchRevisionSessionPlayer(sessionId),
    enabled: Number.isFinite(sessionId),
  });

  const [currentIndex, setCurrentIndex] = useState(0);
  const [selections, setSelections] = useState<Record<number, number | null>>({});
  const initializedRef = useRef(false);
  const touchStartXRef = useRef<number | null>(null);

  useEffect(() => {
    if (playerQuery.data && !initializedRef.current) {
      initializedRef.current = true;
      setCurrentIndex(playerQuery.data.session.currentIndex ?? 0);
      const initSel: Record<number, number | null> = {};
      playerQuery.data.questions.forEach((q) => {
        initSel[q.id] = q.selectedIndex;
      });
      setSelections(initSel);
    }
  }, [playerQuery.data]);

  useEffect(() => {
    setGuard({
      message: "Your revision progress is saved. You can continue this session anytime from the Revision Bank.",
      confirmLabel: "Exit Session",
    });
    return () => setGuard(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const saveMutation = useMutation({
    mutationFn: (vars: { questionId: number; selectedIndex: number | null; currentIndex?: number }) =>
      saveRevisionAnswer(sessionId, vars),
  });
  const navMutation = useMutation({
    mutationFn: (idx: number) => navigateRevisionSession(sessionId, idx),
  });
  const submitMutation = useMutation({
    mutationFn: () => submitRevisionSession(sessionId),
    onSuccess: () => {
      setGuard(null);
      queryClient.invalidateQueries({ queryKey: queryKeys.revisionSummary });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboard });
      router.replace(`/revision/session/${sessionId}/result`);
    },
  });

  if (playerQuery.isError) {
    const message =
      playerQuery.error instanceof ApiError ? playerQuery.error.message : "We couldn't load this revision session.";
    const isInvalidState = playerQuery.error instanceof ApiError && playerQuery.error.code === "INVALID_STATE";
    return (
      <PageShell title="Revision Session" backHref="/revision" hideNav>
        {isInvalidState ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-4 px-8 text-center">
            <p className="text-sm text-slate-500">This session has already finished.</p>
            <PrimaryButton className="w-auto px-6" onClick={() => router.replace(`/revision/session/${sessionId}/result`)}>
              View Results
            </PrimaryButton>
          </div>
        ) : (
          <ErrorState message={message} onRetry={() => playerQuery.refetch()} />
        )}
      </PageShell>
    );
  }

  if (playerQuery.isLoading || !playerQuery.data) {
    return (
      <PageShell title="Revision Session" backHref="/revision" hideNav>
        <FullScreenLoader label="Preparing your revision questions…" />
      </PageShell>
    );
  }

  const { questions } = playerQuery.data;
  const total = questions.length;
  const question = questions[currentIndex];
  const answeredCount = Object.values(selections).filter((v) => v !== null && v !== undefined).length;

  function persistIndex(idx: number) {
    setCurrentIndex(idx);
    navMutation.mutate(idx);
  }
  function selectOption(optionIdx: number) {
    if (!question) return;
    setSelections((prev) => ({ ...prev, [question.id]: optionIdx }));
    saveMutation.mutate({ questionId: question.id, selectedIndex: optionIdx, currentIndex });
  }
  function goNext() {
    if (currentIndex < total - 1) persistIndex(currentIndex + 1);
    else submitMutation.mutate();
  }
  function goPrev() {
    if (currentIndex > 0) persistIndex(currentIndex - 1);
  }
  function onTouchStart(e: ReactTouchEvent) {
    touchStartXRef.current = e.touches[0].clientX;
  }
  function onTouchEnd(e: ReactTouchEvent) {
    if (touchStartXRef.current === null) return;
    const delta = e.changedTouches[0].clientX - touchStartXRef.current;
    touchStartXRef.current = null;
    if (Math.abs(delta) < 60) return;
    if (delta > 0) goPrev();
    else goNext();
  }

  return (
    <PageShell title="Revision Session" subtitle={`Question ${currentIndex + 1} of ${total}`} backHref="/revision" hideNav>
      <div className="flex h-full flex-col">
        <div className="px-4 pt-3">
          <ProgressBar value={((currentIndex + 1) / total) * 100} />
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-5" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
          {question && (
            <div key={question.id} className="animate-fade-in">
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <Badge tone={question.difficulty}>{question.difficulty}</Badge>
                <span className="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-semibold text-slate-600">
                  {question.subjectIcon} {question.subjectName} · {question.topicName}
                </span>
              </div>
              <h2 className="text-[19px] font-semibold leading-snug text-slate-900">{question.prompt}</h2>

              <div className="mt-5 space-y-3">
                {question.options.map((opt, idx) => {
                  const selected = selections[question.id] === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => selectOption(idx)}
                      className={`flex min-h-[56px] w-full items-center gap-3 rounded-2xl border-2 px-4 py-3 text-left text-[15px] font-medium transition active:scale-[0.99] ${
                        selected
                          ? "border-indigo-600 bg-indigo-50 text-indigo-900"
                          : "border-slate-200 bg-white text-slate-700 active:bg-slate-50"
                      }`}
                    >
                      <span
                        className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                          selected ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {OPTION_LETTERS[idx]}
                      </span>
                      <span className="flex-1">{opt}</span>
                    </button>
                  );
                })}
              </div>
              <button
                type="button"
                onClick={goNext}
                className="mt-4 flex min-h-[44px] w-full items-center justify-center text-sm font-semibold text-slate-400 active:text-slate-500"
              >
                Skip this question
              </button>
            </div>
          )}
        </div>
        <div className="flex gap-3 border-t border-slate-200 bg-white px-4 py-3 pb-[calc(env(safe-area-inset-bottom)+0.75rem)]">
          <SecondaryButton onClick={goPrev} disabled={currentIndex === 0} className="flex-[1]">
            Previous
          </SecondaryButton>
          <PrimaryButton onClick={goNext} disabled={submitMutation.isPending} className="flex-[1.4]">
            {submitMutation.isPending ? (
              "Submitting…"
            ) : currentIndex === total - 1 ? (
              <>
                <CheckIcon className="h-4 w-4" /> Finish Session
              </>
            ) : (
              <>
                Next <ChevronRightIcon className="h-4 w-4" />
              </>
            )}
          </PrimaryButton>
        </div>
        <p className="pb-2 text-center text-[11px] text-slate-400">{answeredCount} of {total} answered</p>
      </div>
    </PageShell>
  );
}
