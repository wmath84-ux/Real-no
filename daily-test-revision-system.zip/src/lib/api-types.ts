import type { getDashboardData, getProgressData, getWeakTopics } from "@/server/stats-service";
import type {
  getTodayTestState,
  getAttemptForPlayer,
  getTestResult,
  getTestReview,
} from "@/server/test-service";
import type {
  getRevisionBank,
  getRevisionSummary,
  getRevisionSessionForPlayer,
  getRevisionSessionResult,
  getAllSubjects,
  getTopicsForSubject,
} from "@/server/revision-service";

export type DashboardData = Awaited<ReturnType<typeof getDashboardData>>;
export type TodayTestState = Awaited<ReturnType<typeof getTodayTestState>>;
export type TestPlayerData = Awaited<ReturnType<typeof getAttemptForPlayer>>;
export type TestResultData = Awaited<ReturnType<typeof getTestResult>>;
export type TestReviewData = Awaited<ReturnType<typeof getTestReview>>;

export type RevisionBankData = Awaited<ReturnType<typeof getRevisionBank>>;
export type RevisionSummaryData = Awaited<ReturnType<typeof getRevisionSummary>>;
export type RevisionSessionPlayerData = Awaited<ReturnType<typeof getRevisionSessionForPlayer>>;
export type RevisionSessionResultData = Awaited<ReturnType<typeof getRevisionSessionResult>>;
export type SubjectRow = Awaited<ReturnType<typeof getAllSubjects>>[number];
export type TopicRow = Awaited<ReturnType<typeof getTopicsForSubject>>[number];

export type WeakTopicsData = Awaited<ReturnType<typeof getWeakTopics>>;
export type ProgressData = Awaited<ReturnType<typeof getProgressData>>;

export type ApiEnvelope<T> = { ok: true; data: T } | { ok: false; error: string; code?: string };
