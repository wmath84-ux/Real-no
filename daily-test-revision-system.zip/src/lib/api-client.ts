import type {
  ApiEnvelope,
  DashboardData,
  ProgressData,
  RevisionBankData,
  RevisionSessionPlayerData,
  RevisionSessionResultData,
  RevisionSummaryData,
  SubjectRow,
  TestPlayerData,
  TestResultData,
  TestReviewData,
  TodayTestState,
  TopicRow,
  WeakTopicsData,
} from "./api-types";

export class ApiError extends Error {
  code?: string;
  constructor(message: string, code?: string) {
    super(message);
    this.code = code;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: { "Content-Type": "application/json", ...(init?.headers ?? {}) },
    cache: "no-store",
  });
  let json: ApiEnvelope<T>;
  try {
    json = await res.json();
  } catch {
    throw new ApiError("Something went wrong. Please try again.");
  }
  if (!json.ok) {
    throw new ApiError(json.error, json.code);
  }
  return json.data;
}

// Dashboard
export const fetchDashboard = () => request<DashboardData>("/api/dashboard");

// Daily test
export const fetchTodayTest = () => request<TodayTestState>("/api/tests/today");
export const startTodayTest = () =>
  request<{ attemptId: number }>("/api/tests/today/start", { method: "POST" });
export const fetchTestPlayer = (attemptId: number) =>
  request<TestPlayerData>(`/api/tests/attempts/${attemptId}`);
export const saveTestAnswer = (
  attemptId: number,
  payload: { questionId: number; selectedIndex: number | null; currentIndex?: number },
) =>
  request(`/api/tests/attempts/${attemptId}/answer`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
export const navigateTestAttempt = (attemptId: number, currentIndex: number) =>
  request(`/api/tests/attempts/${attemptId}/navigate`, {
    method: "POST",
    body: JSON.stringify({ currentIndex }),
  });
export const submitTestAttempt = (attemptId: number) =>
  request<{ alreadyCompleted: boolean; attemptId: number }>(
    `/api/tests/attempts/${attemptId}/submit`,
    { method: "POST" },
  );
export const fetchTestResult = (attemptId: number) =>
  request<TestResultData>(`/api/tests/attempts/${attemptId}/result`);
export const fetchTestReview = (attemptId: number) =>
  request<TestReviewData>(`/api/tests/attempts/${attemptId}/review`);

// Revision bank
export type BankQuery = {
  subjectId?: number;
  topicId?: number;
  difficulty?: string;
  status?: string;
  search?: string;
  sort?: string;
};
export const fetchRevisionBank = (query: BankQuery) => {
  const params = new URLSearchParams();
  Object.entries(query).forEach(([k, v]) => {
    if (v !== undefined && v !== "" && v !== null) params.set(k, String(v));
  });
  const qs = params.toString();
  return request<RevisionBankData>(`/api/revision/bank${qs ? `?${qs}` : ""}`);
};
export const fetchRevisionSummary = () => request<RevisionSummaryData>("/api/revision/summary");
export const fetchRevisionMeta = () =>
  request<{ subjects: SubjectRow[]; topics: TopicRow[] }>("/api/revision/meta");

export const fetchActiveRevisionSession = () =>
  request<{ id: number } | null>("/api/revision/sessions");
export const startRevisionSession = (payload: {
  subjectId?: number;
  topicId?: number;
  status?: string;
  limit?: number;
}) => request<{ sessionId: number }>("/api/revision/sessions", { method: "POST", body: JSON.stringify(payload) });
export const fetchRevisionSessionPlayer = (sessionId: number) =>
  request<RevisionSessionPlayerData>(`/api/revision/sessions/${sessionId}`);
export const saveRevisionAnswer = (
  sessionId: number,
  payload: { questionId: number; selectedIndex: number | null; currentIndex?: number },
) =>
  request(`/api/revision/sessions/${sessionId}/answer`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
export const navigateRevisionSession = (sessionId: number, currentIndex: number) =>
  request(`/api/revision/sessions/${sessionId}/navigate`, {
    method: "POST",
    body: JSON.stringify({ currentIndex }),
  });
export const submitRevisionSession = (sessionId: number) =>
  request<{ alreadyCompleted: boolean; sessionId: number }>(
    `/api/revision/sessions/${sessionId}/submit`,
    { method: "POST" },
  );
export const fetchRevisionSessionResult = (sessionId: number) =>
  request<RevisionSessionResultData>(`/api/revision/sessions/${sessionId}/result`);

// Weak topics + progress
export const fetchWeakTopics = () => request<WeakTopicsData>("/api/weak-topics");
export const fetchProgress = () => request<ProgressData>("/api/progress");
