import { db } from "@/db";
import {
  dailyTests,
  testAttempts,
  testAnswers,
  questions,
  topics,
  subjects,
  revisionItems,
} from "@/db/schema";
import { and, eq, inArray, lt, sql } from "drizzle-orm";
import { DEMO_USER_ID, ensureSeed, todayDateStr } from "./db-utils";
import type { PlayerQuestion, ReviewQuestion } from "./types";

export class ServiceError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}

function mulberry32(seed: number) {
  return function () {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return hash;
}

const QUESTIONS_PER_TEST = 10;
const ESTIMATED_MINUTES = 5;

export async function getOrCreateDailyTest(dateStr: string) {
  const existing = await db
    .select()
    .from(dailyTests)
    .where(eq(dailyTests.testDate, dateStr));
  if (existing.length > 0) return existing[0];

  const allQuestions = await db
    .select({ id: questions.id, subjectId: questions.subjectId })
    .from(questions)
    .where(eq(questions.isActive, true));

  if (allQuestions.length === 0) {
    throw new ServiceError("NO_QUESTIONS", "No questions available to build a test.");
  }

  // Deterministic shuffle seeded by date so the test is stable across requests
  const rng = mulberry32(hashString(dateStr));
  const bySubject = new Map<number, number[]>();
  for (const q of allQuestions) {
    const arr = bySubject.get(q.subjectId) ?? [];
    arr.push(q.id);
    bySubject.set(q.subjectId, arr);
  }
  // shuffle within each subject bucket then round-robin pick for topic diversity
  const subjectIds = Array.from(bySubject.keys());
  for (const sid of subjectIds) {
    const arr = bySubject.get(sid)!;
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
  }
  // shuffle subject order too, seeded
  for (let i = subjectIds.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [subjectIds[i], subjectIds[j]] = [subjectIds[j], subjectIds[i]];
  }

  const picked: number[] = [];
  let cursor = 0;
  while (picked.length < QUESTIONS_PER_TEST && picked.length < allQuestions.length) {
    const sid = subjectIds[cursor % subjectIds.length];
    const arr = bySubject.get(sid)!;
    const idx = Math.floor(picked.length / subjectIds.length);
    if (idx < arr.length) {
      picked.push(arr[idx]);
    }
    cursor++;
    if (cursor > subjectIds.length * (QUESTIONS_PER_TEST + 2)) break;
  }

  const [row] = await db
    .insert(dailyTests)
    .values({
      testDate: dateStr,
      title: "Daily 5-Minute Test",
      questionIds: picked,
      totalQuestions: picked.length,
      estimatedMinutes: ESTIMATED_MINUTES,
    })
    .onConflictDoNothing()
    .returning();

  if (row) return row;

  const [again] = await db.select().from(dailyTests).where(eq(dailyTests.testDate, dateStr));
  return again;
}

export async function markExpiredAttempts(userId: number, dateStr: string) {
  const staleTests = await db
    .select({ id: dailyTests.id })
    .from(dailyTests)
    .where(lt(dailyTests.testDate, dateStr));
  const staleIds = staleTests.map((t) => t.id);
  if (staleIds.length === 0) return;
  await db
    .update(testAttempts)
    .set({ status: "expired", updatedAt: new Date() })
    .where(
      and(
        eq(testAttempts.userId, userId),
        inArray(testAttempts.dailyTestId, staleIds),
        eq(testAttempts.status, "in_progress"),
      ),
    );
}

export async function getTodayTestState(userId = DEMO_USER_ID) {
  await ensureSeed();
  const dateStr = todayDateStr();
  await markExpiredAttempts(userId, dateStr);
  const dailyTest = await getOrCreateDailyTest(dateStr);

  const attempts = await db
    .select()
    .from(testAttempts)
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.dailyTestId, dailyTest.id)));
  const attempt = attempts[0] ?? null;

  const lastCompleted = await db
    .select({ testDate: dailyTests.testDate, completedAt: testAttempts.completedAt })
    .from(testAttempts)
    .innerJoin(dailyTests, eq(testAttempts.dailyTestId, dailyTests.id))
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")))
    .orderBy(sql`${testAttempts.completedAt} desc`)
    .limit(1);

  return {
    dailyTest: {
      id: dailyTest.id,
      testDate: dailyTest.testDate,
      title: dailyTest.title,
      totalQuestions: dailyTest.totalQuestions,
      estimatedMinutes: dailyTest.estimatedMinutes,
    },
    attempt: attempt
      ? {
          id: attempt.id,
          status: attempt.status,
          currentIndex: attempt.currentIndex,
          startedAt: attempt.startedAt,
        }
      : null,
    lastCompletedDate: lastCompleted[0]?.testDate ?? null,
  };
}

export async function startOrResumeAttempt(userId = DEMO_USER_ID) {
  await ensureSeed();
  const dateStr = todayDateStr();
  await markExpiredAttempts(userId, dateStr);
  const dailyTest = await getOrCreateDailyTest(dateStr);

  const existing = await db
    .select()
    .from(testAttempts)
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.dailyTestId, dailyTest.id)));

  if (existing.length > 0) {
    if (existing[0].status === "completed") {
      throw new ServiceError("ALREADY_COMPLETED", "Today's test is already completed.");
    }
    if (existing[0].status === "in_progress") {
      return existing[0];
    }
  }

  const [attempt] = await db
    .insert(testAttempts)
    .values({
      userId,
      dailyTestId: dailyTest.id,
      status: "in_progress",
      currentIndex: 0,
    })
    .returning();
  return attempt;
}

async function loadAttemptOrThrow(attemptId: number, userId: number) {
  const rows = await db.select().from(testAttempts).where(eq(testAttempts.id, attemptId));
  const attempt = rows[0];
  if (!attempt || attempt.userId !== userId) {
    throw new ServiceError("NOT_FOUND", "Test attempt not found.");
  }
  return attempt;
}

export async function getAttemptForPlayer(attemptId: number, userId = DEMO_USER_ID) {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This test is not in progress.");
  }
  const [dailyTest] = await db.select().from(dailyTests).where(eq(dailyTests.id, attempt.dailyTestId));
  const ids = dailyTest.questionIds;
  const rows = await db
    .select({
      id: questions.id,
      prompt: questions.prompt,
      options: questions.options,
      difficulty: questions.difficulty,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicId: topics.id,
      topicName: topics.name,
    })
    .from(questions)
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(inArray(questions.id, ids));

  const byId = new Map(rows.map((r) => [r.id, r]));
  const existingAnswers = await db
    .select()
    .from(testAnswers)
    .where(eq(testAnswers.attemptId, attemptId));
  const answerByQ = new Map(existingAnswers.map((a) => [a.questionId, a]));

  const ordered: PlayerQuestion[] = ids
    .map((id) => byId.get(id))
    .filter((q): q is NonNullable<typeof q> => Boolean(q))
    .map((q) => ({
      id: q.id,
      prompt: q.prompt,
      options: q.options,
      difficulty: q.difficulty,
      subjectId: q.subjectId,
      subjectName: q.subjectName,
      subjectIcon: q.subjectIcon,
      topicId: q.topicId,
      topicName: q.topicName,
      selectedIndex: answerByQ.get(q.id)?.selectedIndex ?? null,
    }));

  return {
    attempt: {
      id: attempt.id,
      status: attempt.status,
      currentIndex: attempt.currentIndex,
      startedAt: attempt.startedAt,
    },
    dailyTest: {
      id: dailyTest.id,
      title: dailyTest.title,
      totalQuestions: dailyTest.totalQuestions,
      estimatedMinutes: dailyTest.estimatedMinutes,
    },
    questions: ordered,
  };
}

export async function saveTestAnswer(
  attemptId: number,
  userId: number,
  questionId: number,
  selectedIndex: number | null,
) {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This test is not in progress.");
  }
  const [dailyTest] = await db.select().from(dailyTests).where(eq(dailyTests.id, attempt.dailyTestId));
  if (!dailyTest.questionIds.includes(questionId)) {
    throw new ServiceError("INVALID_QUESTION", "Question does not belong to this test.");
  }
  const [question] = await db.select().from(questions).where(eq(questions.id, questionId));
  if (!question) throw new ServiceError("NOT_FOUND", "Question not found.");
  if (selectedIndex !== null && (selectedIndex < 0 || selectedIndex >= question.options.length)) {
    throw new ServiceError("INVALID_OPTION", "Selected option is out of range.");
  }

  const isSkipped = selectedIndex === null;
  const isCorrect = isSkipped ? null : selectedIndex === question.correctIndex;

  await db
    .insert(testAnswers)
    .values({
      attemptId,
      questionId,
      selectedIndex,
      isCorrect,
      isSkipped,
      answeredAt: new Date(),
    })
    .onConflictDoUpdate({
      target: [testAnswers.attemptId, testAnswers.questionId],
      set: { selectedIndex, isCorrect, isSkipped, answeredAt: new Date() },
    });

  await db.update(testAttempts).set({ updatedAt: new Date() }).where(eq(testAttempts.id, attemptId));

  return { questionId, selectedIndex, isCorrect, isSkipped };
}

export async function updateAttemptIndex(attemptId: number, userId: number, index: number) {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This test is not in progress.");
  }
  await db
    .update(testAttempts)
    .set({ currentIndex: index, updatedAt: new Date() })
    .where(eq(testAttempts.id, attemptId));
  return { currentIndex: index };
}

export async function submitTestAttempt(attemptId: number, userId: number) {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status === "completed") {
    return { alreadyCompleted: true, attemptId };
  }
  if (attempt.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This test cannot be submitted.");
  }
  const [dailyTest] = await db.select().from(dailyTests).where(eq(dailyTests.id, attempt.dailyTestId));
  const ids = dailyTest.questionIds;

  const qRows = await db.select().from(questions).where(inArray(questions.id, ids));
  const qById = new Map(qRows.map((q) => [q.id, q]));

  const existingAnswers = await db.select().from(testAnswers).where(eq(testAnswers.attemptId, attemptId));
  const answerByQ = new Map(existingAnswers.map((a) => [a.questionId, a]));

  // Fill missing (unanswered) with skipped placeholders
  for (const qid of ids) {
    if (!answerByQ.has(qid)) {
      const [inserted] = await db
        .insert(testAnswers)
        .values({ attemptId, questionId: qid, selectedIndex: null, isCorrect: null, isSkipped: true })
        .onConflictDoNothing()
        .returning();
      if (inserted) answerByQ.set(qid, inserted);
    }
  }

  let correctCount = 0;
  let wrongCount = 0;
  let skippedCount = 0;
  for (const qid of ids) {
    const a = answerByQ.get(qid);
    if (!a || a.isSkipped) skippedCount++;
    else if (a.isCorrect) correctCount++;
    else wrongCount++;
  }

  const total = ids.length || 1;
  const score = Math.round((correctCount / total) * 100);
  const timeSpentSeconds = Math.max(
    1,
    Math.round((Date.now() - new Date(attempt.startedAt).getTime()) / 1000),
  );

  await db
    .update(testAttempts)
    .set({
      status: "completed",
      completedAt: new Date(),
      correctCount,
      wrongCount,
      skippedCount,
      score,
      timeSpentSeconds,
      updatedAt: new Date(),
    })
    .where(eq(testAttempts.id, attemptId));

  // Update revision bank: any wrong or skipped question enters/returns to the bank
  for (const qid of ids) {
    const a = answerByQ.get(qid);
    const isWeak = !a || a.isSkipped || a.isCorrect === false;
    if (!isWeak) continue;
    const q = qById.get(qid);
    if (!q) continue;

    const existingItem = await db
      .select()
      .from(revisionItems)
      .where(and(eq(revisionItems.userId, userId), eq(revisionItems.questionId, qid)));

    if (existingItem.length === 0) {
      await db.insert(revisionItems).values({
        userId,
        questionId: qid,
        subjectId: q.subjectId,
        topicId: q.topicId,
        status: "learning",
        successStreak: 0,
        timesSeen: 1,
        timesWrong: a?.isSkipped ? 0 : 1,
        lastResult: a?.isSkipped ? "skipped" : "wrong",
        sourceAttemptId: attemptId,
      });
    } else {
      const item = existingItem[0];
      await db
        .update(revisionItems)
        .set({
          status: "learning",
          successStreak: 0,
          timesSeen: item.timesSeen + 1,
          timesWrong: item.timesWrong + (a?.isSkipped ? 0 : 1),
          lastResult: a?.isSkipped ? "skipped" : "wrong",
          updatedAt: new Date(),
        })
        .where(eq(revisionItems.id, item.id));
    }
  }

  return { alreadyCompleted: false, attemptId };
}

export async function getTestResult(attemptId: number, userId: number) {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status !== "completed") {
    throw new ServiceError("INVALID_STATE", "Test has not been completed yet.");
  }
  const [dailyTest] = await db.select().from(dailyTests).where(eq(dailyTests.id, attempt.dailyTestId));
  const answers = await db.select().from(testAnswers).where(eq(testAnswers.attemptId, attemptId));

  const qRows = await db
    .select({
      id: questions.id,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicId: topics.id,
      topicName: topics.name,
    })
    .from(questions)
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(inArray(questions.id, dailyTest.questionIds));
  const qById = new Map(qRows.map((q) => [q.id, q]));

  const topicMap = new Map<
    number,
    { topicId: number; topicName: string; subjectName: string; subjectIcon: string; total: number; correct: number }
  >();
  for (const a of answers) {
    const meta = qById.get(a.questionId);
    if (!meta) continue;
    const entry = topicMap.get(meta.topicId) ?? {
      topicId: meta.topicId,
      topicName: meta.topicName,
      subjectName: meta.subjectName,
      subjectIcon: meta.subjectIcon,
      total: 0,
      correct: 0,
    };
    entry.total += 1;
    if (a.isCorrect) entry.correct += 1;
    topicMap.set(meta.topicId, entry);
  }

  const total = dailyTest.totalQuestions || 1;
  return {
    attemptId: attempt.id,
    testDate: dailyTest.testDate,
    totalQuestions: dailyTest.totalQuestions,
    correctCount: attempt.correctCount,
    wrongCount: attempt.wrongCount,
    skippedCount: attempt.skippedCount,
    accuracy: Math.round((attempt.correctCount / total) * 100),
    score: attempt.score,
    timeSpentSeconds: attempt.timeSpentSeconds,
    startedAt: attempt.startedAt,
    completedAt: attempt.completedAt,
    topicBreakdown: Array.from(topicMap.values()).map((t) => ({
      ...t,
      accuracy: Math.round((t.correct / t.total) * 100),
    })),
  };
}

export async function getTestReview(attemptId: number, userId: number): Promise<ReviewQuestion[]> {
  const attempt = await loadAttemptOrThrow(attemptId, userId);
  if (attempt.status !== "completed") {
    throw new ServiceError("INVALID_STATE", "Test has not been completed yet.");
  }
  const [dailyTest] = await db.select().from(dailyTests).where(eq(dailyTests.id, attempt.dailyTestId));
  const answers = await db.select().from(testAnswers).where(eq(testAnswers.attemptId, attemptId));
  const answerByQ = new Map(answers.map((a) => [a.questionId, a]));

  const qRows = await db
    .select({
      id: questions.id,
      prompt: questions.prompt,
      options: questions.options,
      correctIndex: questions.correctIndex,
      explanation: questions.explanation,
      difficulty: questions.difficulty,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicName: topics.name,
    })
    .from(questions)
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(inArray(questions.id, dailyTest.questionIds));
  const qById = new Map(qRows.map((q) => [q.id, q]));

  return dailyTest.questionIds
    .map((id) => {
      const q = qById.get(id);
      const a = answerByQ.get(id);
      if (!q) return null;
      return {
        id: q.id,
        prompt: q.prompt,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        difficulty: q.difficulty,
        subjectName: q.subjectName,
        subjectIcon: q.subjectIcon,
        topicName: q.topicName,
        selectedIndex: a?.selectedIndex ?? null,
        isCorrect: a?.isCorrect ?? null,
        isSkipped: a?.isSkipped ?? true,
      };
    })
    .filter((r): r is ReviewQuestion => Boolean(r));
}

