import { db } from "@/db";
import {
  revisionItems,
  revisionSessions,
  revisionSessionAnswers,
  questions,
  topics,
  subjects,
} from "@/db/schema";
import { and, eq, inArray, sql } from "drizzle-orm";
import { DEMO_USER_ID, ensureSeed } from "./db-utils";
import { ServiceError } from "./test-service";
export { ServiceError };
import type { PlayerQuestion } from "./types";

export type BankFilters = {
  subjectId?: number;
  topicId?: number;
  difficulty?: "easy" | "medium" | "hard";
  status?: "learning" | "improving" | "mastered" | "all";
  search?: string;
  sort?: "recent" | "oldest" | "difficulty" | "most_wrong" | "alphabetical";
};

export async function getRevisionBank(userId = DEMO_USER_ID, filters: BankFilters = {}) {
  await ensureSeed();
  const conditions = [eq(revisionItems.userId, userId)];
  if (filters.status && filters.status !== "all") {
    conditions.push(eq(revisionItems.status, filters.status));
  } else if (!filters.status) {
    // default: hide mastered from the primary queue view
    conditions.push(sql`${revisionItems.status} != 'mastered'`);
  }
  if (filters.subjectId) conditions.push(eq(revisionItems.subjectId, filters.subjectId));
  if (filters.topicId) conditions.push(eq(revisionItems.topicId, filters.topicId));

  const rows = await db
    .select({
      id: revisionItems.id,
      questionId: revisionItems.questionId,
      status: revisionItems.status,
      successStreak: revisionItems.successStreak,
      timesSeen: revisionItems.timesSeen,
      timesCorrect: revisionItems.timesCorrect,
      timesWrong: revisionItems.timesWrong,
      lastResult: revisionItems.lastResult,
      addedAt: revisionItems.addedAt,
      lastRevisedAt: revisionItems.lastRevisedAt,
      masteredAt: revisionItems.masteredAt,
      prompt: questions.prompt,
      difficulty: questions.difficulty,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicId: topics.id,
      topicName: topics.name,
    })
    .from(revisionItems)
    .innerJoin(questions, eq(revisionItems.questionId, questions.id))
    .innerJoin(topics, eq(revisionItems.topicId, topics.id))
    .innerJoin(subjects, eq(revisionItems.subjectId, subjects.id))
    .where(and(...conditions));

  let filtered = rows;
  if (filters.difficulty) {
    filtered = filtered.filter((r) => r.difficulty === filters.difficulty);
  }
  if (filters.search && filters.search.trim().length > 0) {
    const q = filters.search.trim().toLowerCase();
    filtered = filtered.filter(
      (r) =>
        r.prompt.toLowerCase().includes(q) ||
        r.topicName.toLowerCase().includes(q) ||
        r.subjectName.toLowerCase().includes(q),
    );
  }

  const difficultyRank: Record<string, number> = { hard: 0, medium: 1, easy: 2 };
  const sort = filters.sort ?? "recent";
  filtered = [...filtered].sort((a, b) => {
    switch (sort) {
      case "oldest":
        return new Date(a.addedAt).getTime() - new Date(b.addedAt).getTime();
      case "difficulty":
        return difficultyRank[a.difficulty] - difficultyRank[b.difficulty];
      case "most_wrong":
        return b.timesWrong - a.timesWrong;
      case "alphabetical":
        return a.topicName.localeCompare(b.topicName);
      case "recent":
      default:
        return new Date(b.addedAt).getTime() - new Date(a.addedAt).getTime();
    }
  });

  return filtered;
}

export async function getRevisionSummary(userId = DEMO_USER_ID) {
  await ensureSeed();
  const rows = await db.select().from(revisionItems).where(eq(revisionItems.userId, userId));
  const learning = rows.filter((r) => r.status === "learning").length;
  const improving = rows.filter((r) => r.status === "improving").length;
  const mastered = rows.filter((r) => r.status === "mastered").length;
  const due = learning + improving;

  const subjectRows = await db
    .select({
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      status: revisionItems.status,
    })
    .from(revisionItems)
    .innerJoin(subjects, eq(revisionItems.subjectId, subjects.id))
    .where(eq(revisionItems.userId, userId));

  const bySubject = new Map<number, { subjectId: number; name: string; icon: string; count: number }>();
  for (const r of subjectRows) {
    if (r.status === "mastered") continue;
    const entry = bySubject.get(r.subjectId) ?? {
      subjectId: r.subjectId,
      name: r.subjectName,
      icon: r.subjectIcon,
      count: 0,
    };
    entry.count += 1;
    bySubject.set(r.subjectId, entry);
  }

  return {
    total: rows.length,
    learning,
    improving,
    mastered,
    due,
    bySubject: Array.from(bySubject.values()).sort((a, b) => b.count - a.count),
  };
}

async function loadSessionOrThrow(sessionId: number, userId: number) {
  const rows = await db.select().from(revisionSessions).where(eq(revisionSessions.id, sessionId));
  const session = rows[0];
  if (!session || session.userId !== userId) {
    throw new ServiceError("NOT_FOUND", "Revision session not found.");
  }
  return session;
}

export async function findActiveSession(userId = DEMO_USER_ID) {
  const rows = await db
    .select()
    .from(revisionSessions)
    .where(and(eq(revisionSessions.userId, userId), eq(revisionSessions.status, "in_progress")))
    .orderBy(sql`${revisionSessions.startedAt} desc`)
    .limit(1);
  return rows[0] ?? null;
}

export async function startRevisionSession(
  userId = DEMO_USER_ID,
  filters: { subjectId?: number; topicId?: number; status?: string; limit?: number } = {},
) {
  await ensureSeed();

  const existingActive = await findActiveSession(userId);
  if (existingActive) return existingActive;

  const conditions = [eq(revisionItems.userId, userId)];
  if (filters.status === "mastered") {
    conditions.push(eq(revisionItems.status, "mastered"));
  } else {
    conditions.push(sql`${revisionItems.status} != 'mastered'`);
  }
  if (filters.subjectId) conditions.push(eq(revisionItems.subjectId, filters.subjectId));
  if (filters.topicId) conditions.push(eq(revisionItems.topicId, filters.topicId));

  const eligible = await db
    .select()
    .from(revisionItems)
    .where(and(...conditions));

  if (eligible.length === 0) {
    throw new ServiceError("NO_ITEMS", "No revision questions available for this filter.");
  }

  const statusRank: Record<string, number> = { learning: 0, improving: 1, mastered: 2 };
  const sorted = [...eligible].sort((a, b) => {
    const rankDiff = statusRank[a.status] - statusRank[b.status];
    if (rankDiff !== 0) return rankDiff;
    const aTime = a.lastRevisedAt ? new Date(a.lastRevisedAt).getTime() : 0;
    const bTime = b.lastRevisedAt ? new Date(b.lastRevisedAt).getTime() : 0;
    return aTime - bTime;
  });

  const limit = filters.limit ?? 10;
  const chosen = sorted.slice(0, limit);
  const questionIds = chosen.map((c) => c.questionId);

  const [session] = await db
    .insert(revisionSessions)
    .values({
      userId,
      status: "in_progress",
      filterSubjectId: filters.subjectId ?? null,
      filterTopicId: filters.topicId ?? null,
      filterStatus: filters.status ?? null,
      questionIds,
      totalQuestions: questionIds.length,
      currentIndex: 0,
    })
    .returning();

  return session;
}

export async function getRevisionSessionForPlayer(sessionId: number, userId = DEMO_USER_ID) {
  const session = await loadSessionOrThrow(sessionId, userId);
  if (session.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This revision session is not in progress.");
  }
  const ids = session.questionIds;
  const rows = await db
    .select({
      id: questions.id,
      prompt: questions.prompt,
      options: questions.options,
      difficulty: questions.difficulty,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicId: topics.id,
      topicName: topics.name,
    })
    .from(questions)
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(inArray(questions.id, ids));
  const byId = new Map(rows.map((r) => [r.id, r]));

  const existingAnswers = await db
    .select()
    .from(revisionSessionAnswers)
    .where(eq(revisionSessionAnswers.sessionId, sessionId));
  const answerByQ = new Map(existingAnswers.map((a) => [a.questionId, a]));

  const ordered: PlayerQuestion[] = ids
    .map((id) => byId.get(id))
    .filter((q): q is NonNullable<typeof q> => Boolean(q))
    .map((q) => ({
      id: q.id,
      prompt: q.prompt,
      options: q.options,
      difficulty: q.difficulty,
      subjectId: q.subjectId,
      subjectName: q.subjectName,
      subjectIcon: q.subjectIcon,
      topicId: q.topicId,
      topicName: q.topicName,
      selectedIndex: answerByQ.get(q.id)?.selectedIndex ?? null,
    }));

  return {
    session: {
      id: session.id,
      currentIndex: session.currentIndex,
      totalQuestions: session.totalQuestions,
      startedAt: session.startedAt,
    },
    questions: ordered,
  };
}

export async function saveRevisionAnswer(
  sessionId: number,
  userId: number,
  questionId: number,
  selectedIndex: number | null,
) {
  const session = await loadSessionOrThrow(sessionId, userId);
  if (session.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This revision session is not in progress.");
  }
  if (!session.questionIds.includes(questionId)) {
    throw new ServiceError("INVALID_QUESTION", "Question does not belong to this session.");
  }
  const [question] = await db.select().from(questions).where(eq(questions.id, questionId));
  if (!question) throw new ServiceError("NOT_FOUND", "Question not found.");
  if (selectedIndex !== null && (selectedIndex < 0 || selectedIndex >= question.options.length)) {
    throw new ServiceError("INVALID_OPTION", "Selected option is out of range.");
  }
  const [item] = await db
    .select()
    .from(revisionItems)
    .where(and(eq(revisionItems.userId, userId), eq(revisionItems.questionId, questionId)));
  if (!item) throw new ServiceError("NOT_FOUND", "Revision item not found.");

  const isSkipped = selectedIndex === null;
  const isCorrect = isSkipped ? null : selectedIndex === question.correctIndex;

  await db
    .insert(revisionSessionAnswers)
    .values({
      sessionId,
      revisionItemId: item.id,
      questionId,
      selectedIndex,
      isCorrect,
      isSkipped,
      answeredAt: new Date(),
    })
    .onConflictDoUpdate({
      target: [revisionSessionAnswers.sessionId, revisionSessionAnswers.questionId],
      set: { selectedIndex, isCorrect, isSkipped, answeredAt: new Date() },
    });

  return { questionId, selectedIndex, isCorrect, isSkipped };
}

export async function updateRevisionSessionIndex(sessionId: number, userId: number, index: number) {
  const session = await loadSessionOrThrow(sessionId, userId);
  if (session.status !== "in_progress") {
    throw new ServiceError("INVALID_STATE", "This revision session is not in progress.");
  }
  await db
    .update(revisionSessions)
    .set({ currentIndex: index })
    .where(eq(revisionSessions.id, sessionId));
  return { currentIndex: index };
}

export async function submitRevisionSession(sessionId: number, userId: number) {
  const session = await loadSessionOrThrow(sessionId, userId);
  if (session.status === "completed") {
    return { alreadyCompleted: true, sessionId };
  }

  const ids = session.questionIds;
  const existingAnswers = await db
    .select()
    .from(revisionSessionAnswers)
    .where(eq(revisionSessionAnswers.sessionId, sessionId));
  const answerByQ = new Map(existingAnswers.map((a) => [a.questionId, a]));

  const items = await db
    .select()
    .from(revisionItems)
    .where(and(eq(revisionItems.userId, userId), inArray(revisionItems.questionId, ids)));
  const itemByQ = new Map(items.map((it) => [it.questionId, it]));

  let correctCount = 0;

  for (const qid of ids) {
    let answer = answerByQ.get(qid);
    if (!answer) {
      const item = itemByQ.get(qid);
      if (!item) continue;
      const [inserted] = await db
        .insert(revisionSessionAnswers)
        .values({
          sessionId,
          revisionItemId: item.id,
          questionId: qid,
          selectedIndex: null,
          isCorrect: null,
          isSkipped: true,
        })
        .onConflictDoNothing()
        .returning();
      if (inserted) answer = inserted;
    }
    const item = itemByQ.get(qid);
    if (!item || !answer) continue;

    const statusBefore = item.status;
    let statusAfter = statusBefore;
    let successStreak = item.successStreak;
    let timesCorrect = item.timesCorrect;
    let timesWrong = item.timesWrong;

    if (answer.isCorrect) {
      correctCount += 1;
      successStreak += 1;
      timesCorrect += 1;
      if (statusBefore === "learning") statusAfter = "improving";
      else if (statusBefore === "improving") statusAfter = "mastered";
      else statusAfter = "mastered";
    } else {
      successStreak = 0;
      if (!answer.isSkipped) timesWrong += 1;
      if (statusBefore === "mastered") statusAfter = "improving";
      else statusAfter = "learning";
    }

    await db
      .update(revisionItems)
      .set({
        status: statusAfter,
        successStreak,
        timesSeen: item.timesSeen + 1,
        timesCorrect,
        timesWrong,
        lastResult: answer.isSkipped ? "skipped" : answer.isCorrect ? "correct" : "wrong",
        lastRevisedAt: new Date(),
        masteredAt: statusAfter === "mastered" && statusBefore !== "mastered" ? new Date() : item.masteredAt,
        updatedAt: new Date(),
      })
      .where(eq(revisionItems.id, item.id));

    await db
      .update(revisionSessionAnswers)
      .set({ statusBefore, statusAfter })
      .where(eq(revisionSessionAnswers.id, answer.id));
  }

  await db
    .update(revisionSessions)
    .set({ status: "completed", completedAt: new Date(), correctCount })
    .where(eq(revisionSessions.id, sessionId));

  return { alreadyCompleted: false, sessionId };
}

export async function getRevisionSessionResult(sessionId: number, userId: number) {
  const session = await loadSessionOrThrow(sessionId, userId);
  if (session.status !== "completed") {
    throw new ServiceError("INVALID_STATE", "This revision session is not completed yet.");
  }

  const answers = await db
    .select()
    .from(revisionSessionAnswers)
    .where(eq(revisionSessionAnswers.sessionId, sessionId));

  const qRows = await db
    .select({
      id: questions.id,
      prompt: questions.prompt,
      options: questions.options,
      correctIndex: questions.correctIndex,
      explanation: questions.explanation,
      difficulty: questions.difficulty,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
      topicName: topics.name,
    })
    .from(questions)
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(inArray(questions.id, session.questionIds));
  const qById = new Map(qRows.map((q) => [q.id, q]));
  const answerByQ = new Map(answers.map((a) => [a.questionId, a]));

  const total = session.totalQuestions || 1;
  const skipped = answers.filter((a) => a.isSkipped).length;
  const wrong = answers.filter((a) => !a.isSkipped && a.isCorrect === false).length;

  const items = session.questionIds
    .map((id) => {
      const q = qById.get(id);
      const a = answerByQ.get(id);
      if (!q) return null;
      return {
        id: q.id,
        prompt: q.prompt,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        difficulty: q.difficulty,
        subjectName: q.subjectName,
        subjectIcon: q.subjectIcon,
        topicName: q.topicName,
        selectedIndex: a?.selectedIndex ?? null,
        isCorrect: a?.isCorrect ?? null,
        isSkipped: a?.isSkipped ?? true,
        statusBefore: a?.statusBefore ?? null,
        statusAfter: a?.statusAfter ?? null,
      };
    })
    .filter((r): r is NonNullable<typeof r> => Boolean(r));

  return {
    sessionId: session.id,
    totalQuestions: session.totalQuestions,
    correctCount: session.correctCount,
    wrongCount: wrong,
    skippedCount: skipped,
    accuracy: Math.round((session.correctCount / total) * 100),
    startedAt: session.startedAt,
    completedAt: session.completedAt,
    promoted: items.filter((i) => i.statusAfter && i.statusBefore && i.statusAfter !== i.statusBefore && i.statusAfter !== "learning").length,
    mastered: items.filter((i) => i.statusAfter === "mastered" && i.statusBefore !== "mastered").length,
    items,
  };
}

export async function getTopicsForSubject(subjectId?: number) {
  await ensureSeed();
  if (subjectId) {
    return db.select().from(topics).where(eq(topics.subjectId, subjectId));
  }
  return db.select().from(topics);
}

export async function getAllSubjects() {
  await ensureSeed();
  return db.select().from(subjects);
}

