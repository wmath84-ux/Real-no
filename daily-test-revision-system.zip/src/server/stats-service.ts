import { db } from "@/db";
import {
  testAnswers,
  testAttempts,
  dailyTests,
  questions,
  topics,
  subjects,
  revisionItems,
  revisionSessions,
  revisionSessionAnswers,
} from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import {
  format,
  startOfDay,
  subDays,
  startOfWeek,
  subWeeks,
  startOfMonth,
  subMonths,
  isAfter,
  isBefore,
  isEqual,
} from "date-fns";
import { DEMO_USER_ID, ensureSeed, todayDateStr, daysAgoDateStr } from "./db-utils";
import { getOrCreateDailyTest, markExpiredAttempts } from "./test-service";
import { getRevisionSummary } from "./revision-service";

type TopicAgg = {
  topicId: number;
  topicName: string;
  subjectId: number;
  subjectName: string;
  subjectIcon: string;
  total: number;
  correct: number;
  wrong: number;
  skipped: number;
  recentTotal: number;
  recentCorrect: number;
  priorTotal: number;
  priorCorrect: number;
};

async function collectTopicAnswers(userId: number) {
  const rows = await db
    .select({
      isCorrect: testAnswers.isCorrect,
      isSkipped: testAnswers.isSkipped,
      answeredAt: testAnswers.answeredAt,
      topicId: topics.id,
      topicName: topics.name,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
    })
    .from(testAnswers)
    .innerJoin(testAttempts, eq(testAnswers.attemptId, testAttempts.id))
    .innerJoin(questions, eq(testAnswers.questionId, questions.id))
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")));

  const revisionRows = await db
    .select({
      isCorrect: revisionSessionAnswers.isCorrect,
      isSkipped: revisionSessionAnswers.isSkipped,
      answeredAt: revisionSessionAnswers.answeredAt,
      topicId: topics.id,
      topicName: topics.name,
      subjectId: subjects.id,
      subjectName: subjects.name,
      subjectIcon: subjects.icon,
    })
    .from(revisionSessionAnswers)
    .innerJoin(revisionSessions, eq(revisionSessionAnswers.sessionId, revisionSessions.id))
    .innerJoin(questions, eq(revisionSessionAnswers.questionId, questions.id))
    .innerJoin(topics, eq(questions.topicId, topics.id))
    .innerJoin(subjects, eq(questions.subjectId, subjects.id))
    .where(and(eq(revisionSessions.userId, userId), eq(revisionSessions.status, "completed")));

  return [...rows, ...revisionRows];
}

export async function getWeakTopics(userId = DEMO_USER_ID) {
  await ensureSeed();
  const answers = await collectTopicAnswers(userId);

  const now = new Date();
  const recentStart = subDays(now, 7);
  const priorStart = subDays(now, 14);

  const map = new Map<number, TopicAgg>();
  for (const a of answers) {
    const entry = map.get(a.topicId) ?? {
      topicId: a.topicId,
      topicName: a.topicName,
      subjectId: a.subjectId,
      subjectName: a.subjectName,
      subjectIcon: a.subjectIcon,
      total: 0,
      correct: 0,
      wrong: 0,
      skipped: 0,
      recentTotal: 0,
      recentCorrect: 0,
      priorTotal: 0,
      priorCorrect: 0,
    };
    entry.total += 1;
    if (a.isSkipped) entry.skipped += 1;
    else if (a.isCorrect) entry.correct += 1;
    else entry.wrong += 1;

    const answeredAt = a.answeredAt ? new Date(a.answeredAt) : null;
    if (answeredAt) {
      if (isAfter(answeredAt, recentStart)) {
        entry.recentTotal += 1;
        if (a.isCorrect) entry.recentCorrect += 1;
      } else if (isAfter(answeredAt, priorStart) && isBefore(answeredAt, recentStart)) {
        entry.priorTotal += 1;
        if (a.isCorrect) entry.priorCorrect += 1;
      }
    }
    map.set(a.topicId, entry);
  }

  const topicList = Array.from(map.values()).map((t) => {
    const accuracy = t.total > 0 ? Math.round((t.correct / t.total) * 100) : 0;
    const recentAcc = t.recentTotal > 0 ? Math.round((t.recentCorrect / t.recentTotal) * 100) : null;
    const priorAcc = t.priorTotal > 0 ? Math.round((t.priorCorrect / t.priorTotal) * 100) : null;
    let trend: "improving" | "declining" | "stable" | "new" = "new";
    if (recentAcc !== null && priorAcc !== null) {
      if (recentAcc - priorAcc >= 5) trend = "improving";
      else if (priorAcc - recentAcc >= 5) trend = "declining";
      else trend = "stable";
    } else if (recentAcc !== null) {
      trend = "new";
    }
    return { ...t, accuracy, recentAccuracy: recentAcc, trend };
  });

  const weakest = [...topicList]
    .filter((t) => t.total >= 1)
    .sort((a, b) => a.accuracy - b.accuracy)
    .slice(0, 8);

  const mostMissed = [...topicList]
    .filter((t) => t.wrong > 0)
    .sort((a, b) => b.wrong - a.wrong)
    .slice(0, 6);

  const frequentlySkipped = [...topicList]
    .filter((t) => t.skipped > 0)
    .sort((a, b) => b.skipped - a.skipped)
    .slice(0, 6);

  const weakestSubjectsMap = new Map<number, { subjectId: number; name: string; icon: string; total: number; correct: number }>();
  for (const t of topicList) {
    const s = weakestSubjectsMap.get(t.subjectId) ?? {
      subjectId: t.subjectId,
      name: t.subjectName,
      icon: t.subjectIcon,
      total: 0,
      correct: 0,
    };
    s.total += t.total;
    s.correct += t.correct;
    weakestSubjectsMap.set(t.subjectId, s);
  }
  const weakestSubjects = Array.from(weakestSubjectsMap.values())
    .map((s) => ({ ...s, accuracy: s.total > 0 ? Math.round((s.correct / s.total) * 100) : 0 }))
    .filter((s) => s.total >= 1)
    .sort((a, b) => a.accuracy - b.accuracy)
    .slice(0, 5);

  const recommended = weakest.filter((t) => t.accuracy < 80).slice(0, 3);

  return {
    hasData: answers.length > 0,
    weakestTopics: weakest,
    weakestSubjects,
    mostMissedTopics: mostMissed,
    frequentlySkippedTopics: frequentlySkipped,
    recommendedTopics: recommended,
  };
}

async function getCurrentStreak(userId: number) {
  let streak = 0;
  for (let i = 0; i < 90; i++) {
    const dateStr = daysAgoDateStr(i);
    const [dt] = await db.select().from(dailyTests).where(eq(dailyTests.testDate, dateStr));
    if (!dt) {
      if (i === 0) continue;
      break;
    }
    const [attempt] = await db
      .select()
      .from(testAttempts)
      .where(
        and(
          eq(testAttempts.userId, userId),
          eq(testAttempts.dailyTestId, dt.id),
          eq(testAttempts.status, "completed"),
        ),
      );
    if (attempt) {
      streak += 1;
    } else if (i === 0) {
      continue;
    } else {
      break;
    }
  }
  return streak;
}

export async function getDashboardData(userId = DEMO_USER_ID) {
  await ensureSeed();
  const dateStr = todayDateStr();
  await markExpiredAttempts(userId, dateStr);
  const dailyTest = await getOrCreateDailyTest(dateStr);

  const attempts = await db
    .select()
    .from(testAttempts)
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.dailyTestId, dailyTest.id)));
  const todayAttempt = attempts[0] ?? null;

  const lastCompleted = await db
    .select({ testDate: dailyTests.testDate, completedAt: testAttempts.completedAt, attemptId: testAttempts.id })
    .from(testAttempts)
    .innerJoin(dailyTests, eq(testAttempts.dailyTestId, dailyTests.id))
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")))
    .orderBy(sql`${testAttempts.completedAt} desc`)
    .limit(1);

  const allCompleted = await db
    .select({ correctCount: testAttempts.correctCount, totalQuestions: dailyTests.totalQuestions })
    .from(testAttempts)
    .innerJoin(dailyTests, eq(testAttempts.dailyTestId, dailyTests.id))
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")));

  const testsCompleted = allCompleted.length;
  const totalCorrect = allCompleted.reduce((sum, a) => sum + a.correctCount, 0);
  const totalQ = allCompleted.reduce((sum, a) => sum + a.totalQuestions, 0);
  const overallAccuracy = totalQ > 0 ? Math.round((totalCorrect / totalQ) * 100) : 0;

  const streak = await getCurrentStreak(userId);
  const weakTopics = await getWeakTopics(userId);
  const revisionSummary = await getRevisionSummary(userId);

  let status: "available" | "in_progress" | "completed" | "expired" = "available";
  if (todayAttempt) {
    status = todayAttempt.status === "completed" ? "completed" : todayAttempt.status === "expired" ? "expired" : "in_progress";
  }

  return {
    today: {
      dailyTestId: dailyTest.id,
      title: dailyTest.title,
      totalQuestions: dailyTest.totalQuestions,
      estimatedMinutes: dailyTest.estimatedMinutes,
      status,
      attemptId: todayAttempt?.id ?? null,
      currentIndex: todayAttempt?.currentIndex ?? 0,
      score: todayAttempt?.status === "completed" ? todayAttempt.score : null,
    },
    lastCompletedDate: lastCompleted[0]?.testDate ?? null,
    quickStats: {
      testsCompleted,
      overallAccuracy,
      streak,
    },
    weakTopicSummary: weakTopics.weakestTopics.slice(0, 3),
    revisionBankSummary: revisionSummary,
  };
}

function bucketDaily(
  answers: { isCorrect: boolean | null; isSkipped: boolean; answeredAt: Date | string | null }[],
  days: number,
) {
  const buckets: { date: string; label: string; attempted: number; correct: number; accuracy: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const day = startOfDay(subDays(new Date(), i));
    const dateStr = format(day, "yyyy-MM-dd");
    let attempted = 0;
    let correct = 0;
    for (const a of answers) {
      if (!a.answeredAt) continue;
      const d = startOfDay(new Date(a.answeredAt));
      if (isEqual(d, day)) {
        if (!a.isSkipped) attempted += 1;
        if (a.isCorrect) correct += 1;
      }
    }
    buckets.push({
      date: dateStr,
      label: format(day, "EEE"),
      attempted,
      correct,
      accuracy: attempted > 0 ? Math.round((correct / attempted) * 100) : 0,
    });
  }
  return buckets;
}

function bucketWeekly(
  answers: { isCorrect: boolean | null; isSkipped: boolean; answeredAt: Date | string | null }[],
  weeks: number,
) {
  const buckets: { date: string; label: string; attempted: number; correct: number; accuracy: number }[] = [];
  for (let i = weeks - 1; i >= 0; i--) {
    const weekStart = startOfWeek(subWeeks(new Date(), i));
    const weekEnd = startOfWeek(subWeeks(new Date(), i - 1));
    let attempted = 0;
    let correct = 0;
    for (const a of answers) {
      if (!a.answeredAt) continue;
      const d = new Date(a.answeredAt);
      if ((isEqual(d, weekStart) || isAfter(d, weekStart)) && isBefore(d, weekEnd)) {
        if (!a.isSkipped) attempted += 1;
        if (a.isCorrect) correct += 1;
      }
    }
    buckets.push({
      date: format(weekStart, "yyyy-MM-dd"),
      label: `Wk of ${format(weekStart, "MMM d")}`,
      attempted,
      correct,
      accuracy: attempted > 0 ? Math.round((correct / attempted) * 100) : 0,
    });
  }
  return buckets;
}

function bucketMonthly(
  answers: { isCorrect: boolean | null; isSkipped: boolean; answeredAt: Date | string | null }[],
  months: number,
) {
  const buckets: { date: string; label: string; attempted: number; correct: number; accuracy: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const monthStart = startOfMonth(subMonths(new Date(), i));
    const monthEnd = startOfMonth(subMonths(new Date(), i - 1));
    let attempted = 0;
    let correct = 0;
    for (const a of answers) {
      if (!a.answeredAt) continue;
      const d = new Date(a.answeredAt);
      if ((isEqual(d, monthStart) || isAfter(d, monthStart)) && isBefore(d, monthEnd)) {
        if (!a.isSkipped) attempted += 1;
        if (a.isCorrect) correct += 1;
      }
    }
    buckets.push({
      date: format(monthStart, "yyyy-MM-dd"),
      label: format(monthStart, "MMM"),
      attempted,
      correct,
      accuracy: attempted > 0 ? Math.round((correct / attempted) * 100) : 0,
    });
  }
  return buckets;
}

export async function getProgressData(userId = DEMO_USER_ID) {
  await ensureSeed();

  const answers = await collectTopicAnswers(userId);

  const completedAttempts = await db
    .select()
    .from(testAttempts)
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")))
    .orderBy(sql`${testAttempts.completedAt} desc`)
    .limit(15);

  const completedSessions = await db
    .select()
    .from(revisionSessions)
    .where(and(eq(revisionSessions.userId, userId), eq(revisionSessions.status, "completed")))
    .orderBy(sql`${revisionSessions.completedAt} desc`)
    .limit(15);

  const masteredItems = await db
    .select()
    .from(revisionItems)
    .where(and(eq(revisionItems.userId, userId), eq(revisionItems.status, "mastered")));

  const questionsAttempted = answers.filter((a) => !a.isSkipped).length;
  const questionsCorrect = answers.filter((a) => a.isCorrect).length;
  const questionsIncorrect = answers.filter((a) => !a.isSkipped && a.isCorrect === false).length;

  const daily = bucketDaily(answers, 14);
  const weekly = bucketWeekly(answers, 8);
  const monthly = bucketMonthly(answers, 6);

  const accuracyTrend = [...completedAttempts]
    .reverse()
    .map((a) => ({
      date: a.completedAt ? format(new Date(a.completedAt), "MMM d") : "",
      score: a.score,
    }));

  const activityHistory = [
    ...completedAttempts.map((a) => ({
      type: "test" as const,
      title: "Daily Test completed",
      date: a.completedAt ?? a.startedAt,
      detail: `${a.correctCount}/${a.correctCount + a.wrongCount + a.skippedCount} correct · Score ${a.score}%`,
      refId: a.id,
    })),
    ...completedSessions.map((s) => ({
      type: "revision" as const,
      title: "Revision session completed",
      date: s.completedAt ?? s.startedAt,
      detail: `${s.correctCount}/${s.totalQuestions} correct`,
      refId: s.id,
    })),
  ]
    .sort((a, b) => new Date(b.date as Date).getTime() - new Date(a.date as Date).getTime())
    .slice(0, 20);

  return {
    totals: {
      testsCompleted: completedAttempts.length > 0 ? await countAllCompletedTests(userId) : 0,
      questionsAttempted,
      questionsCorrect,
      questionsIncorrect,
      revisionSessionsCompleted: await countAllCompletedSessions(userId),
      masteredCount: masteredItems.length,
      overallAccuracy: questionsAttempted > 0 ? Math.round((questionsCorrect / questionsAttempted) * 100) : 0,
      currentStreak: await getCurrentStreak(userId),
    },
    daily,
    weekly,
    monthly,
    accuracyTrend,
    activityHistory,
  };
}

async function countAllCompletedTests(userId: number) {
  const rows = await db
    .select({ id: testAttempts.id })
    .from(testAttempts)
    .where(and(eq(testAttempts.userId, userId), eq(testAttempts.status, "completed")));
  return rows.length;
}

async function countAllCompletedSessions(userId: number) {
  const rows = await db
    .select({ id: revisionSessions.id })
    .from(revisionSessions)
    .where(and(eq(revisionSessions.userId, userId), eq(revisionSessions.status, "completed")));
  return rows.length;
}
