import { db } from "@/db";
import { subjects, topics, questions, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { SEED_SUBJECTS, SEED_TOPICS, SEED_QUESTIONS } from "./seed-data";

export const DEMO_USER_ID = 1;

let seedPromise: Promise<void> | null = null;

async function seed() {
  // Ensure demo user exists
  const userRows = await db.select().from(users).where(eq(users.id, DEMO_USER_ID));
  if (userRows.length === 0) {
    await db.insert(users).values({ id: DEMO_USER_ID, name: "Alex" });
    // reset sequence in case of explicit id insert
    await db.execute(
      sql`SELECT setval(pg_get_serial_sequence('users','id'), (SELECT COALESCE(MAX(id),1) FROM users))`,
    );
  }

  const existingSubjects = await db.select().from(subjects);
  if (existingSubjects.length > 0) {
    return;
  }

  const subjectIdBySlug = new Map<string, number>();
  for (const s of SEED_SUBJECTS) {
    const [row] = await db
      .insert(subjects)
      .values({ name: s.name, slug: s.slug, icon: s.icon, color: s.color })
      .returning({ id: subjects.id });
    subjectIdBySlug.set(s.slug, row.id);
  }

  const topicIdBySlug = new Map<string, number>();
  for (const t of SEED_TOPICS) {
    const subjectId = subjectIdBySlug.get(t.subjectSlug);
    if (!subjectId) continue;
    const [row] = await db
      .insert(topics)
      .values({ name: t.name, slug: t.slug, subjectId })
      .returning({ id: topics.id });
    topicIdBySlug.set(t.slug, row.id);
  }

  for (const q of SEED_QUESTIONS) {
    const topicId = topicIdBySlug.get(q.topicSlug);
    const topicMeta = SEED_TOPICS.find((t) => t.slug === q.topicSlug);
    const subjectId = topicMeta ? subjectIdBySlug.get(topicMeta.subjectSlug) : undefined;
    if (!topicId || !subjectId) continue;
    await db.insert(questions).values({
      topicId,
      subjectId,
      difficulty: q.difficulty,
      prompt: q.prompt,
      options: q.options,
      correctIndex: q.correctIndex,
      explanation: q.explanation,
      isActive: true,
    });
  }
}

export function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seed().catch((err) => {
      seedPromise = null;
      throw err;
    });
  }
  return seedPromise;
}

export function todayDateStr(d = new Date()): string {
  const year = d.getUTCFullYear();
  const month = String(d.getUTCMonth() + 1).padStart(2, "0");
  const day = String(d.getUTCDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function daysAgoDateStr(days: number, from = new Date()): string {
  const d = new Date(from);
  d.setUTCDate(d.getUTCDate() - days);
  return todayDateStr(d);
}
